import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "ClassyCrafth | Corporate & School Uniform Manufacturer India",
  description:
    "Premium corporate uniform manufacturer, school uniform supplier, and corporate gift supplier in India. Bulk production, custom branding, quality assurance and timely delivery.",
  keywords: [
    "Corporate Uniform Manufacturer",
    "School Uniform Manufacturer",
    "Corporate Gifts Supplier",
    "Bulk Uniform Supplier India",
    "Custom Corporate Uniforms",
    "School Dress Manufacturer"
  ],
  openGraph: {
    title: "ClassyCrafth | Premium Uniform Manufacturer",
    description:
      "Bulk corporate and school uniform manufacturing with quality control and custom branding solutions.",
    url: "https://classycrafth.com",
    siteName: "ClassyCrafth",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}